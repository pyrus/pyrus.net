<?php
namespace Pyrus\Developer\Creator;
class Exception extends \PEAR2\Exception {}