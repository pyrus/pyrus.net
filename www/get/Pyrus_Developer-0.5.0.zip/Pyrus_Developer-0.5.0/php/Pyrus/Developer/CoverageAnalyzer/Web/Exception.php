<?php
namespace Pyrus\Developer\CoverageAnalyzer\Web {
class Exception extends \Exception {}
}
?>
