<?php
namespace Pyrus\Developer\Runphpt;
class Exception extends \PEAR2\Exception {}