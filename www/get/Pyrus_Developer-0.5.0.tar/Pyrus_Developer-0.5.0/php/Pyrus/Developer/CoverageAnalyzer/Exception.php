<?php
namespace Pyrus\Developer\CoverageAnalyzer {
class Exception extends \Exception {}
}
?>
